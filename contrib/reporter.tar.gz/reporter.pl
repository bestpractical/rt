#! /sc/adm/bin/perl
#
#  Reporter.pl						$Author: root $
#  $Header: /sc/adm/rt/contrib/RCS/reporter.pl,v 0.96 1998/02/03 15:00:53 root Exp $
#
#  Generates a simple report based upon the current RT database.  Ideally,
#  this program should be run weekly, but it can be run at any time.  Options
#  are to generate a report for a specific timeframe, a year-to-date report,
#  or a complete-from-inception report.
#
#  The generated report will include a breakdown by area, requestor, number
#  of transactions per day, number of new tickets per day, number of resolved
#  tickets per day, and others.
#
## NOTE ##
##
#  This file's location should be in the contrib directory of the final
#  installation, NOT where the source of the software is kept.
##
## NOTE ##

##
# Main requirements
##
require "getopts.pl";
require "../etc/config.pm";
use Mysql;

##
# Global Definitions
##
$TMPDIR = "$RT_PATH/tmp/reports";
$OUTPUT_REPORT = "$TMPDIR/report";
@prompts = ("Report Type", "Queue name", "Mail Report to");
@opts = ("t", "q", "m");
$WHO = $ENV{'USER'} || getlogin;
@defaults = ("weekly", "help", "$WHO");
@types = ("weekly", "monthly", "yearly", "ytd", "complete");

##
# Time information (Do Not Touch)
##
$DAY_VALUE = 86400;          # A 24 Hour Day
$WEEK_VALUE = 604800;        # A 7 Day Week
$MONTH_VALUE = 2592000;      # Based upon a 30 Day Month
$YEAR_VALUE = 31536000;      # Based upon a 365 Day Year.

##
# Define all of our formatting
##

##
# Header specific format
##
format HEADER =
         Queue : @<<<<<<<<<<          Timeframe: @############ to @############
$queue, $ALL, $tod
.

##
# Summary formats for the weekly output
##
format DAY_CREATE_SUMMARY =
New Tickets   | @#### | @#### | @#### | @#### | @#### | @#### | @#### | @####
$CREATE[0], $CREATE[1], $CREATE[2], $CREATE[3], $CREATE[4], $CREATE[5], $CREATE[6], ($CREATE[0] + $CREATE[1] + $CREATE[2] + $CREATE[3] + $CREATE[4] + $CREATE[5] + $CREATE[6])
.

format DAY_RESOLVED_SUMMARY =
Resolved      | @#### | @#### | @#### | @#### | @#### | @#### | @#### | @####
$RESOLVED[0], $RESOLVED[1], $RESOLVED[2], $RESOLVED[3], $RESOLVED[4], $RESOLVED[5], $RESOLVED[6], ($RESOLVED[0] + $RESOLVED[1] + $RESOLVED[2] + $RESOLVED[3] + $RESOLVED[4] + $RESOLVED[5] + $RESOLVED[6])
.

format DAY_TRANSACTION_SUMMARY =
Transactions  | @#### | @#### | @#### | @#### | @#### | @#### | @#### | @####
$TRANSACTIONS[0], $TRANSACTIONS[1], $TRANSACTIONS[2], $TRANSACTIONS[3], $TRANSACTIONS[4], $TRANSACTIONS[5], $TRANSACTIONS[6], ($TRANSACTIONS[0] + $TRANSACTIONS[1] + $TRANSACTIONS[2] + $TRANSACTIONS[3] + $TRANSACTIONS[4] + $TRANSACTIONS[5] + $TRANSACTIONS[6])
.

format DAY_CHART = 
@<<<<<<<<<<<< | @#### | @#### | @#### | @#### | @#### | @#### | @#### | @######
$areas[$i], $AREA_ROW[$count], $AREA_ROW[$count+1], $AREA_ROW[$count+2], $AREA_ROW[$count+3], $AREA_ROW[$count+4], $AREA_ROW[$count+5], $AREA_ROW[$count+6], ($AREA_ROW[$count] + $AREA_ROW[$count+1] + $AREA_ROW[$count+2] + $AREA_ROW[$count+3] +  $AREA_ROW[$count+4] + $AREA_ROW[$count+5] + $AREA_ROW[$count+6])
.

format DAY_TOTALS =
TOTALS        | @#### | @#### | @#### | @#### | @#### | @#### | @#### | @######
$DAY_TOTAL[0], $DAY_TOTAL[1], $DAY_TOTAL[2], $DAY_TOTAL[3], $DAY_TOTAL[4], $DAY_TOTAL[5], $DAY_TOTAL[6],($DAY_TOTAL[0] + $DAY_TOTAL[1] + $DAY_TOTAL[2] + $DAY_TOTAL[3] + $DAY_TOTAL[4] + $DAY_TOTAL[5] + $DAY_TOTAL[6])
.

##
# Summary formats for the month
##
format WEEK_CREATE_SUMMARY =
New Tickets   |  @#####  |  @#####  |  @#####  |  @#####  | @######
$CREATE[0], $CREATE[1], $CREATE[2], $CREATE[3], ($CREATE[0] + $CREATE[1] + $CREATE[2] + $CREATE[3])
.

format WEEK_RESOLVED_SUMMARY =
Resolved      |  @#####  |  @#####  |  @#####  |  @#####  | @######
$RESOLVED[0], $RESOLVED[1], $RESOLVED[2], $RESOLVED[3], ($RESOLVED[0] + $RESOLVED[1] + $RESOLVED[2] + $RESOLVED[3])
.

format WEEK_TRANSACTION_SUMMARY =
Transactions  |  @#####  |  @#####  |  @#####  |  @#####  | @######
$TRANSACTIONS[0], $TRANSACTIONS[1], $TRANSACTIONS[2], $TRANSACTIONS[3], ($TRANSACTIONS[0] + $TRANSACTIONS[1] + $TRANSACTIONS[2] + $TRANSACTIONS[3])
.

format WEEK_CHART = 
@<<<<<<<<<<<< |  @#####  |  @#####  |  @#####  |  @#####  | @######
$areas[$i], $AREA_ROW[$count], $AREA_ROW[$count+1], $AREA_ROW[$count+2], $AREA_ROW[$count+3], ($AREA_ROW[$count] + $AREA_ROW[$count+1] + $AREA_ROW[$count+2] + $AREA_ROW[$count+3])
.

format WEEK_TOTALS =
TOTALS        |  @#####  |  @#####  |  @#####  |  @#####  | @######
$WEEK_TOTAL[0], $WEEK_TOTAL[1], $WEEK_TOTAL[2], $WEEK_TOTAL[3], ($WEEK_TOTAL[0] + $WEEK_TOTAL[1] + $WEEK_TOTAL[2] + $WEEK_TOTAL[3])
.

##
# Summary formats for the year
##
format MONTH_CREATE_SUMMARY =
New Tickets   |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  | @######
$CREATE[0], $CREATE[1], $CREATE[2], $CREATE[3], $CREATE[4], $CREATE[5], $CREATE[6], $CREATE[7], $CREATE[8], $CREATE[9], $CREATE[10], $CREATE[11], ($CREATE[0] + $CREATE[1] + $CREATE[2] + $CREATE[3] + $CREATE[4] + $CREATE[5]  + $CREATE[6] + $CREATE[7] + $CREATE[8] + $CREATE[9] + $CREATE[10] + $CREATE [11])
.

format MONTH_RESOLVED_SUMMARY =
Resolved      |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  | @######
$RESOLVED[0], $RESOLVED[1], $RESOLVED[2], $RESOLVED[3], $RESOLVED[4], $RESOLVED[5], $RESOLVED[6], $RESOLVED[7], $RESOLVED[8], $RESOLVED[9], $RESOLVED[10], $RESOLVED[11], ($RESOLVED[0] + $RESOLVED[1] + $RESOLVED[2] + $RESOLVED[3] + $RESOLVED[4] + $RESOLVED[5]  + $RESOLVED[6] + $RESOLVED[7] + $RESOLVED[8] + $RESOLVED[9] + $RESOLVED[10] + $RESOLVED [11])
.

format MONTH_TRANSACTION_SUMMARY =
Transactions  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  | @######
$TRANSACTIONS[0], $TRANSACTIONS[1], $TRANSACTIONS[2], $TRANSACTIONS[3], $TRANSACTIONS[4], $TRANSACTIONS[5], $TRANSACTIONS[6], $TRANSACTIONS[7], $TRANSACTIONS[8], $TRANSACTIONS[9], $TRANSACTIONS[10], $TRANSACTIONS[11], ($TRANSACTIONS[0] + $TRANSACTIONS[1] + $TRANSACTIONS[2] + $TRANSACTIONS[3] + $TRANSACTIONS[4] + $TRANSACTIONS[5]  + $TRANSACTIONS[6] + $TRANSACTIONS[7] + $TRANSACTIONS[8] + $TRANSACTIONS[9] + $TRANSACTIONS[10] + $TRANSACTIONS [11])
.

format MONTH_CHART = 
@<<<<<<<<<<<<<|  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  | @######
$areas[$i], $AREA_ROW[$count], $AREA_ROW[$count+1], $AREA_ROW[$count+2], $AREA_ROW[$count+3], $AREA_ROW[$count+4], $AREA_ROW[$count+5], $AREA_ROW[$count+6], $AREA_ROW[$count+7], $AREA_ROW[$count+8], $AREA_ROW[$count+9], $AREA_ROW[$count+10], $AREA_ROW[$count+11], ($AREA_ROW[$count] + $AREA_ROW[$count+1] + $AREA_ROW[$count+2] + $AREA_ROW[$count+3] + $AREA_ROW[$count+4] + $AREA_ROW[$count+5]  + $AREA_ROW[$count+6] + $AREA_ROW[$count+7] + $AREA_ROW[$count+8] + $AREA_ROW[$count+9] + $AREA_ROW[$count+10] + $AREA_ROW [$count+11])
.

format MONTH_TOTALS =
TOTALS        |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  |  @#####  | @######
$MONTH_TOTAL[0], $MONTH_TOTAL[1], $MONTH_TOTAL[2], $MONTH_TOTAL[3], $MONTH_TOTAL[4], $MONTH_TOTAL[5], $MONTH_TOTAL[6], $MONTH_TOTAL[7], $MONTH_TOTAL[8], $MONTH_TOTAL[9], $MONTH_TOTAL[10], $MONTH_TOTAL[11], ($MONTH_TOTAL[0] + $MONTH_TOTAL[1] + $MONTH_TOTAL[2] + $MONTH_TOTAL[3] + $MONTH_TOTAL[4] + $MONTH_TOTAL[5]  + $MONTH_TOTAL[6] + $MONTH_TOTAL[7] + $MONTH_TOTAL[8] + $MONTH_TOTAL[9] + $MONTH_TOTAL[10] + $MONTH_TOTAL [11])
.

format YTD_CHART =
@<<<<<<<<<<<<<<< |  @##### @##### @##### @##### @##### @##### @##### @##### @##### @##### @##### @##### | @########
$AREA[i], $MONTH[i], $MONTH[i+1], $MONTH[i+2], $MONTH[i+3], $MONTH[i+4], $MONTH[i+5], $MONTH[i+6], $MONTH[i+7], $MONTH[i+8], $MONTH[i+9], $MONTH[i+10], $MONTH[i+11], ($MONTH[i], $MONTH[i+1], $MONTH[i+2], $MONTH[i+3], $MONTH[i+4], $MONTH[i+5], $MONTH[i+6], $MONTH[i+7], $MONTH[i+8], $MONTH[i+9], $MONTH[i+10], $MONTH[i+11])
.

######  
##
# Make sure we are being executed properly
##
sub usage
{
   $prog_name = `basename $0`;
   chop($prog_name);
   print STDERR "usage: $prog_name -t<report type> -m<username> -q<queue name>\n";
   exit;
}

##
# Manage the input via standard input.
##
sub munge
{
   local($_,$prompt,$default) = @_;
   local($response);
   local($done) = 0;

   while (!$done)
   {
      print ($prompt," <",$default,">: ") ;
      chop($response = <STDIN>);
      if (!length($response)) { $response = $default; }
      $done = &check($_,$response) ;
   }
   return ($response);
}

##
# Check each of the settings to make sure they are valid.
##
sub check
{
   local($_,$response) = @_;
   local($done) = 0;

   chk_rsp:
   {
       if (/t/ && (&valid_type($response))) { $done = 1; last chk_rsp;}
#       if (/m/ && (&exist_user($response))) { $done = 1; last chk_rsp;}
       if (/m/) { $response="root"; $done = 1; last chk_rsp;}
       if (/q/ && (&exist_queue($response))) { $done = 1; last chk_rsp;}
       &erroneous($_);
   }
   return ($done);
}

##
# Confirm that the type of report requested is a valid one.
##
sub valid_type
{
   local($_) = @_;
   local($i) = 0;

   for ( $i = 0; $i <= $#types; $i++)
   {
      if (/$types[$i]/)
      {
         return (1);
      }
   }
   return (0);
}

##
# Confirm that the queue entered exists.
##
sub exist_queue
{
   local($queue) = @_;
   local($query_string, $sth, @row) = "";

   &connectdb($host,$dbname,$rtpass,$rtuser);
   $query_string="SELECT queue_id from queues where queue_id = \"$queue\"";
   $sth=$dbh->Query($query_string) or warn "Query had some problem: $Mysql::db_errstr\n$query_string";
   @row=$sth->FetchRow;
   if (!$row[0])
   {
      return 0;
   }
   return 1;
}

##
# An extremely minimal check to see if the report is to be sent to a valid
# local user.
##
sub exist_user
{
   local($_) = @_;

##
# If an at sign exists, then we can't confirm the email address.
##
   if (/\@/)
   {
      return (1);
   }
##
# Assuming that the user is local, so let's make sure it exists.
##
   open (YP, "ypmatch $_ passwd 2>&1 |") || die "Could not execute ypmatch.\n";
   $_ = <YP>;
   close (YP);
   if (/no such key in map/)
   {
      return (0);
   }
   return (1);
}

##
# Display the proper input error.
##
sub erroneous
{
   local($_) = @_;

   print "Error: ";
   err_response:
   {
      if (/t/)
      {
         print "No such Report Type supported.\n";
         last err_response;
      }
      if (/q/)
      {
         print "No such queue exists.\n";
         last err_response;
      }
      if (/m/)
      {
         print "Username does not exist locally.\n";
         last err_response;
      }
   }
}

##
# Connect to the database
##
sub connectdb
{
   if (!($dbh = Mysql->Connect($host, $dbname, $rtpass, $rtuser)))
   {
      die "[connectdb] Database connect failed: $Mysql::db_errstr\n";
   }
}

##
# Grab all of the areas
##
sub get_areas
{
   local($queue) = @_;
   local(@areas, $query_string, $sth, @row, $i) = "";

   &connectdb($host,$dbname,$rtpass,$rtuser);
   $query_string = "SELECT area from queue_areas";
   $sth=$dbh->Query($query_string) or warn "Query had some problem: $Mysql::db_errstr\n$query_string";
   while (@row=$sth->FetchRow)
   {
      $areas[$i] = $row[0];
      $i++;
   }
   return (@areas);
}

##
# Grab all of the global ticket elements within the supplied timespan
##
sub get_total_count
{
   local($current_time, $timespan, $TYPE, $area, $flag) = @_;
   local($count, $query_string, $sth) = "";
   local($count) = 0;

   &connectdb($host,$dbname,$rtpass,$rtuser);
   if ($TYPE eq "area")
   {
      if ($flag)
      {
         $query_string = "SELECT count(serial_num) from transactions where trans_date < $current_time and trans_date > $timespan and type like '$TYPE' and trans_data like '$area'";
      }
      else
      {
         $query_string = "SELECT count(serial_num) from transactions where trans_date < $current_time and trans_date > $timespan and type like '$TYPE'";
      }
   }
   else
   {
      if ($TYPE eq "resolved")
      {
         $query_string = "SELECT count(serial_num) from transactions where trans_date < $current_time and trans_date > $timespan and type like 'status' and trans_data like 'resolved'";
      }
      else
      {
         $query_string = "SELECT count(serial_num) from transactions where trans_date < $current_time and type like '$TYPE' and trans_date > $timespan";
      }
   }
   $sth=$dbh->Query($query_string) or warn "Query had some problem: $Mysql::db_errstr\n$query_string";
   while (@row=$sth->FetchRow)
   {
      return ($row[0]);
   }
}

##
# Create the weekly report.  Go back exactly 7 days and generate the report
# based upon that.
##
sub generate_weekly
{
   local($queue, $current_time, @areas) = @_;
   local($correspond) = "";
   local($count, $i, $j) = 0;

##
# Get the totals for each day of the week.
##
   for ($i=0; $i<7; $i++)
   {
      $CREATE[$i]=&get_total_count(($current_time - ($DAY_VALUE * $i)), ($current_time - ($DAY_VALUE * ($i + 1))), "create", 0);
      $correspond=&get_total_count(($current_time - ($DAY_VALUE * $i)), ($current_time - ($DAY_VALUE * ($i + 1))), "correspond", 0);
      $RESOLVED[$i]=&get_total_count(($current_time - ($DAY_VALUE * $i)), ($current_time - ($DAY_VALUE * ($i+1))), "resolved", 0);
      $TRANSACTIONS[$i] = $CREATE[$i] + $correspond;
   }
##
# Get the totals for the week for each area.
##
   for ($i=0; $i<=$#areas; $i++)
   {
##
# Get total for the day for each area.
##
      for ($j=0; $j<7; $j++)
      {
         $AREA_ROW[$count] = &get_total_count( ($current_time - ($j * $DAY_VALUE)), ($current_time - (($j+1) * $DAY_VALUE)), "area", $areas[$i], 1);
         $DAY_TOTAL[$j] = $AREA_ROW[$count] + $DAY_TOTAL[$j];
         $count++;
         $AREA_TOTALS[$i] = $AREA_ROW[$j] + $AREA_TOTALS[$i];
      }
   }
}

##
# Create the monthly report.  Go back exactly 4 weeks and generate the report
# based upon that time span.
##
sub generate_monthly
{
   local($queue, $current_time, @areas) = @_;
   local($correspond) = "";
   local($i) = 0;

##
# Get the totals for each week of the month.
##
   for ($i=0; $i<4; $i++)
   {
      $CREATE[$i]=&get_total_count(($current_time - ($WEEK_VALUE * $i)), ($current_time - ($WEEK_VALUE * ($i+1))), "create", 0);
      $correspond=&get_total_count(($current_time - ($WEEK_VALUE * $i)), ($current_time - ($WEEK_VALUE * ($i+1))), "correspond", 0);
      $RESOLVED[$i]=&get_total_count(($current_time - ($WEEK_VALUE * $i)), ($current_time - ($WEEK_VALUE * ($i+1))), "resolved", 0);
      $TRANSACTIONS[$i] = $CREATE[$i] + $correspond;
   }
##
# Get the totals for each area for each week of the month
##
   for ($i=0; $i<=$#areas; $i++)
   {
##
# Get total for the week for each area.
##
      for ($j=0; $j<4; $j++)
      {
         $AREA_ROW[$count] = &get_total_count( ($current_time - ($j * $WEEK_VALUE)), ($current_time - (($j+1) * $WEEK_VALUE)), "area", $areas[$i], 1);
         $WEEK_TOTAL[$j] = $AREA_ROW[$count] + $WEEK_TOTAL[$j];
         $count++;
         $AREA_TOTALS[$i] = $AREA_ROW[$j] + $AREA_TOTALS[$i];
      }
   }
}

##
# Create the monthly report.  Go back exactly 12 months and generate the report
# based upon that time span.
##
sub generate_yearly
{
   local($queue, $current_time, @areas) = @_;
   local($create, $correspond) = "";
   local($i) = 0;
 
##
# Get the totals for each month
##
   for ($i=0; $i<12; $i++)
   {
      $CREATE[$i]=&get_total_count(($current_time - ($MONTH_VALUE * $i)), ($current_time - ($MONTH_VALUE * ($i+1))), "create", 0);
      $correspond=&get_total_count(($current_time - ($MONTH_VALUE * $i)), ($current_time - ($MONTH_VALUE * ($i+1))), "correspond", 0);
      $RESOLVED[$i]=&get_total_count(($current_time - ($MONTH_VALUE * $i)), ($current_time - ($MONTH_VALUE * ($i+1))), "resolved", 0);
      $TRANSACTIONS[$i] = $CREATE[$i] + $correspond;
   }
##
# Get the totals for each area for each month.
##
   for ($i=0; $i<=$#areas; $i++)
   {
##
# Get total for the month for each area.
##
      for ($j=0; $j<12; $j++)
      {
         $AREA_ROW[$count] = &get_total_count( ($current_time - ($j * $MONTH_VALUE)), ($current_time - (($j+1) * $MONTH_VALUE)), "area", $areas[$i], 1);
         $MONTH_TOTAL[$j] = $AREA_ROW[$count] + $MONTH_TOTAL[$j];
         $count++;
         $AREA_TOTALS[$i] = $AREA_ROW[$j] + $AREA_TOTALS[$i];
      }
   }
}

##
# Create the year-to-date report.  From Jan 1 of the current year until now.
##
sub generate_ytd
{
   local($queue, $current_time, @areas) = @_;
   local($timepassed, $create, $correspond) = "";
   local($i) = 0;

##
# Determine the amount of time that has passed from the first of the year.
##
   $timepassed = int($current_time / $YEAR_VALUE);
   $timepassed = $current_time - ($timepassed * $YEAR_VALUE);

##
# Get the totals for each month.
##
   for ($i=0; $i < $timepassed; $i * $MONTH_VALUE)
   {
      $CREATE[$i]=&get_total_count(($current_time - ($MONTH_VALUE * $i)), ($current_time - ($MONTH_VALUE * ($i+1))), "create", 0);
      $correspond=&get_total_count(($current_time - ($MONTH_VALUE * $i)), ($current_time - ($MONTH_VALUE * ($i+1))), "correspond", 0);
      $RESOLVED[$i]=&get_total_count(($current_time - ($MONTH_VALUE * $i)), ($current_time - ($MONTH_VALUE * ($i+1))), "resolved", 0);
      $TRANSACTIONS[$i] = $CREATE[$i] + $correspond;
      $months++;
   }
##
# Get the totals for each area for each month.
##
   for ($i=0; $i<=$#areas; $i++)
   {
##
# Get total for the month for each area.
##
      for ($j=0; $j<$timepassed; $j++)
      {
         $AREA_ROW[$count] = &get_total_count( ($current_time - ($j * $MONTH_VALUE)), ($current_time - (($j+1) * $MONTH_VALUE)), "area", $areas[$i], 1);
         $MONTH_TOTAL[$j] = $AREA_ROW[$count] + $MONTH_TOTAL[$j];
         $count++;
         $AREA_TOTALS[$i] = $AREA_ROW[$j] + $AREA_TOTALS[$i];
      }
   }
}

##
# Create the complete report.  This is a report of the ENTIRE contents of the
# database.
##
sub generate_complete
{
   local($queue, $current_time, @areas) = @_;
   local($create, $correspond) = "";
   local($i) = 0;

##
# Get the totals for the entire contents of the database
##
   $create=&get_total_count( $current_time, 0, "create", 0);
   $correspond=&get_total_count( $current_time, 0, "correspond", 0);
   $TOTALS[1] = $create + $correspond;
##
# Get the totals for each area in the entire contents of the database
##
   for ($i=0; $i<$#areas; $i++)
   {
      $AREA_TOTALS[$i] = &get_total_count($current_time, 0, "area", $areas[$i]);
      if (!$AREA_TOTALS[$i]) { $AREA_TOTALS[$i] = 0; }
   }
}

##
# Print the weekly form!
##
sub print_weekly
{
   local($queue, $tod) = @_;
   local($count, $i, $j) = 0;

   select(STDOUT);
   $ALL = $tod - (7*$DAY_VALUE);
   $~ = HEADER;
   write;
   print "\nSummary Information of all transactions:\n";
   print "    Area      | Day-1 | Day-2 | Day-3 | Day-4 | Day-5 | Day-6 | Day-7 |   Total\n";
   print "________________________________________________________________________________\n";
   $~ = DAY_CREATE_SUMMARY;
   write;
   $~ = DAY_RESOLVED_SUMMARY;
   write;
   $~ = DAY_TRANSACTION_SUMMARY;
   write;
   print "________________________________________________________________________________\n";

   print "\nNew Ticket Summary for the last seven Days:\n";
   print "    Area      | Day-1 | Day-2 | Day-3 | Day-4 | Day-5 | Day-6 | Day-7 |   Total\n";
   print "________________________________________________________________________________\n";
   for ($i=0; $i<=$#areas; $i++)
   {
      $~ = DAY_CHART;
      write;
      $count = $count + 7;
   }
   print "________________________________________________________________________________\n";
   $~ = DAY_TOTALS;
   write;
}

##
# Print the monthly form!
##
sub print_monthly
{
   local($queue, $tod) = @_;
   local($count, $i, $j) = 0;

   select(STDOUT);
   $ALL = $tod - (4*$WEEK_VALUE);
   $~ = HEADER;
   write;
   print "\nSummary Information of all transactions:\n";
   print "    Area      |  Week-1  |  Week-2  |  Week-3  |  Week-4  |   Total\n";
   print "________________________________________________________________________________\n";
   $~ = WEEK_CREATE_SUMMARY;
   write;
   $~ = WEEK_RESOLVED_SUMMARY;
   write;
   $~ = WEEK_TRANSACTION_SUMMARY;
   write;
   print "________________________________________________________________________________\n";

   print "\nNew Ticket Summary for the last four weeks:\n";
   print "    Area      |  Week-1  |  Week-2  |  Week-3  |  Week-4  |   Total\n";
   print "________________________________________________________________________________\n";
   for ($i=0; $i<=$#areas; $i++)
   {
      $~ = WEEK_CHART;
      write;
      $count = $count + 4;
   }
   print "________________________________________________________________________________\n";
   $~ = WEEK_TOTALS;
   write;
}

##
# Print the yearly form!
##
sub print_yearly
{
   local($queue, $tod) = @_;
   local($count, $i, $j) = 0;

   select(STDOUT);
   $ALL = $tod - (12*$MONTH_VALUE);
   $~ = HEADER;
   write;
   print "\nSummary Information of all transactions:\n";
   print "    Area      |  Month-1  |  Month-2  |  Month-3  |  Month-4  |  Month-5  |  Month-6  |  Month-7  |  Month-8  |  Month-9  |  Month-10 |  Month-11 |  Month-12 |  Total\n";
   print "________________________________________________________________________________\n";
   $~ = MONTH_CREATE_SUMMARY;
   write;
   $~ = MONTH_RESOLVED_SUMMARY;
   write;
   $~ = MONTH_TRANSACTION_SUMMARY;
   write;
   print "________________________________________________________________________________\n";

   print "\nNew Ticket Summary for the last twelve months:\n";
   print "    Area      |  Month-1  |  Month-2  |  Month-3  |  Month-4  |  Month-5  |  Month-6  |  Month-7  |  Month-8  |  Month-9  |  Month-10 |  Month-11 |  Month-12 |  Total\n";
   print "________________________________________________________________________________\n";
   for ($i=0; $i<=$#areas; $i++)
   {
      $~ = MONTH_CHART;
      write;
      $count = $count + 12;
   }
   print "________________________________________________________________________________\n";
   $~ = MONTH_TOTALS;
   write;
}

##
# Print the ytd form!
##
sub print_ytd
{
   local($queue, $tod) = @_;
   local($count, $i, $j) = 0;

   select(STDOUT);
   $ALL = $tod - ($months*$MONTH_VALUE);
   $~ = HEADER;
   write;
   print "\nSummary Information of all transactions:\n";
   print "    Area      |  Month-1  |  Month-2  |  Month-3  |  Month-4  |  Month-5  |  Month-6  |  Month-7  |  Month-8  |  Month-9  |  Month-10 |  Month-11 |  Month-12 |  Total\n";
   print "  Total\n";
   print "________________________________________________________________________________\n";
   $~ = MONTH_CREATE_SUMMARY;
   write;
   $~ = MONTH_RESOLVED_SUMMARY;
   write;
   $~ = MONTH_TRANSACTION_SUMMARY;
   write;
   print "________________________________________________________________________________\n";

   print "\nNew Ticket Summary for the Year To Date:\n";
   print "    Area      |  Month-1  |  Month-2  |  Month-3  |  Month-4  |  Month-5  |  Month-6  |  Month-7  |  Month-8  |  Month-9  |  Month-10 |  Month-11 |  Month-12 |  Total\n";
   print "________________________________________________________________________________\n";
   for ($i=0; $i<=$#areas; $i++)
   {
      $~ = MONTH_CHART;
      write;
      $count = $count + 12;
   }
   print "________________________________________________________________________________\n";
   $~ = MONTH_TOTALS;
   write;
}
sub print_complete
{
   local($queue) = @_;
   local($i) = 0;
 
print "Total tickets + correspondence: $TOTALS[$i] \n";
   for ($i=1; $i<=$#AREA_TOTALS; $i++)
   {
      print "$areas[$i] = $AREA_TOTALS[$i]\n";
   }
}

##
# Determine which report to generate, and create it.
##
sub generate
{
   local(@input) = @_;
   local($i, $tod) = 0;

   @areas=&get_areas($input[1]);
   $tod = $^T;
   rep_type:
   {
      if ($input[0] eq "weekly")
      {
         &generate_weekly($input[1], $tod, @areas);
         &print_weekly($input[1], $tod);
         last rep_type;
      }
      if ($input[0] eq "monthly")
      {
         &generate_monthly($input[1], $^T, @areas);
         &print_monthly($input[1], $tod);
         last rep_type;
      }
      if ($input[0] eq "yearly")
      {
         &generate_yearly($input[1], $^T, @areas);
         &print_yearly($input[1], $tod);
         last rep_type;
      }
      if ($input[0] eq "ytd")
      {
         &generate_ytd($input[1], $^T, @areas);
         &print_ytd($input[1]);
         last rep_type;
      }
      if ($input[0] eq "complete")
      {
         &generate_complete($input[1], $^T, @areas);
         &print_complete($input[1]);
         last rep_type;
      }
   }
}

##
# Send the saved & formatted message to the requested user
##
sub mail
{
   local(@input) = @_;

   open (MAIL, "| $mailprog") || die "Could not start $mailprog.\n";
   print MAIL
"To: $input[2]
Subject: $input[0] report of $input[1]";
   open (FILE, "cat $TMPFILE |" ) || die "Could not read $TMPFILE.\n";
   while (<FILE>)
   {
      print MAIL $_;
   }
   close (FILE);
   close (MAIL);
}

##
# We control things from here.
##
sub main
{
   local($i) = 0;
##
# Check usage and break apart the command line/STDIN options.
##
   &usage if !&Getopts(join(':',@opts));
   for ( $i = 0; $i <= $#opts; $i++)
   {
      if (eval "(!defined (\$opt_$opts[$i]) || !length(\$opt_$opts[$i]))")
      {
         $vars[$i] = &munge($opts[$i],$prompts[$i],$defaults[$i]);
      }
      else
      {
         eval "\$vars[$i] = \$opt_$opts[$i];";
         die "program exit" if (!&check($opts[$i],$vars[$i])) ;
      }
   }
##
# Now that we know that the usage is correct, start generating those reports.
##
   &generate(@vars);
##
# And mail the whole thing out, as requested.
##
#   &mail(@vars);
}

##
# Let's start by calling main.
##

&main;



##
# History of Changes
##
# $Log: reporter.pl,v $
# Revision 0.96  1998/02/03 15:00:53  root
# Updated to use mySQL's built-in count() function.  This should save
# some CPU cycles. -Rich
#
# Revision 0.95  1998/02/03 14:22:38  root
# Another change.
# -Rich
#
# Revision 1.2  1998/02/03 14:21:56  root
# Minor change.
#
